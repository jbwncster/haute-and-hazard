$ErrorActionPreference = "Stop"
$bundle = Split-Path -Parent $MyInvocation.MyCommand.Path
$assets = Join-Path $bundle "assets"
$saves = Join-Path $bundle "saves"
$ttsSaves = Join-Path ([Environment]::GetFolderPath("MyDocuments")) "My Games\Tabletop Simulator\Saves"
New-Item -ItemType Directory -Force -Path $ttsSaves | Out-Null
$assetUri = ([System.Uri]($assets + [IO.Path]::DirectorySeparatorChar)).AbsoluteUri.TrimEnd('/')
Get-ChildItem $saves -Filter *.json | ForEach-Object {
    $text = Get-Content $_.FullName -Raw
    $text = $text.Replace("__ASSET_ROOT__", $assetUri)
    $destination = Join-Path $ttsSaves $_.Name
    [IO.File]::WriteAllText($destination, $text, [Text.UTF8Encoding]::new($false))
    Write-Host "Installed $destination"
}
Write-Host "Open Tabletop Simulator, choose Games > Save & Load, and open a Haute & Hazard v7.7 save."
