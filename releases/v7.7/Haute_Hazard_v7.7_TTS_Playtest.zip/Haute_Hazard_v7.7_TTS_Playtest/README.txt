HAUTE & HAZARD v7.7 - TABLETOP SIMULATOR PLAYTEST

TESTING VERSIONS

The project files include multiple numbered playtest versions so testers can
compare rules, card layouts, and balance changes. Use v7.7 for the current Judge,
Spotlight Requirement, Featured Brand, and Brand Ovation test. Older files are
retained only for comparison and should not be mixed into the same game.

INCLUDED SAVES

1. Haute_Hazard_v7.7_Standard_Setup.json
   Full 2-5 player setup with five starter decks, Wardrobe Rack, Thrift Store,
   Penalty Stack, Stage Deck, all 12 Queens, two player mats, and counters.

2. Haute_Hazard_v7.7_Two_Player_Teaching_Setup.json
   Siren Diesel vs. Opal Dynasty, Face Face Face as the Active Stage, and the
   fixed beginner Market Row from the scripted first game.

WINDOWS INSTALL

1. Extract this entire folder somewhere permanent. Do not move it after install.
2. Right-click INSTALL_WINDOWS.ps1 and choose Run with PowerShell.
3. In Tabletop Simulator, choose Games > Save & Load.
4. Open the desired Haute & Hazard v7.7 save.

If Windows blocks the script, open PowerShell in this folder and run:
  powershell -ExecutionPolicy Bypass -File .\INSTALL_WINDOWS.ps1

MANUAL INSTALL / MAC / LINUX

1. Copy either JSON file from saves into Tabletop Simulator's Saves folder.
2. Replace every __ASSET_ROOT__ in the copied JSON with the absolute file URI
   for this bundle's assets folder, without a trailing slash.
3. Keep the assets folder in that location while using the save.

ONLINE MULTIPLAYER

This local playtest keeps all art on your computer. Other online players will
not automatically receive local file assets. After confirming the table works,
use Tabletop Simulator's Cloud Manager to upload the mod assets, then save a
cloud-backed version before inviting remote testers or publishing to Workshop.

CONTROLS

- Hover a deck and press R to shuffle.
- Drag the top Wardrobe card into an empty Market Row space to refill it.
- Put purchases into the buyer's Backstage Archive.
- Use the labeled counters for current Tips, current Appeal, and persistent SP.
- Draw three cards from personal Decks for Dragdagulan and total only their
  printed LS plus explicit modifiers.

Each Stage now includes a Judge, an optional Spotlight Requirement, a Featured
Brand, and two independent bonus opportunities: Judge's Favor and Brand Ovation.

The v7.7 Rulebook, glossary Player Aid, and printable card set are included in
the companion core playtest package.
