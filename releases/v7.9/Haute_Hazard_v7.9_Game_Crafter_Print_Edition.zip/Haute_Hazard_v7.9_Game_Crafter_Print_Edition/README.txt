Haute & Hazard v7.9 — Game Crafter Print Edition

Upload-ready functional prototype generated from the canonical v7.9 CSV data.
Counts: 240 core game-card fronts, 12 Stages, 12 Queens, 5 Player Aid fronts + 5 backs.
Core game cards: 825x1125 px. Stages: 900x1500 px tarot full bleed / 825x1425 trim. Queens: 1125x1725 px. Player Aids: 1875x1275 px.
Rules folio: 4875x2475 px. Box artboard: 5850x5400 px.

All essential core game-card text is generated from data/v7_9_card_database.csv.
Stage text is generated from data/v7_9_stage_database.csv, verified from the v7.8 venue print assets and migrated to the v7.9 build.
Queen text is generated from data/v7_9_queen_database.csv.
Prototype graphics are intentionally utilitarian; replace art without changing dimensions or safe-text placement.
EDGE COLOR RULE: use one black bleed/trim-edge color across every full-color card; keep Tenet colors inside the card so face-down decks and hands do not reveal card information from the side.
ART-SPACE RULE: every core game card, Queen, and Stage front reserves a generic silhouette area so final illustration space is tested before commissioning art.
Core game-card essential text remains inside the existing safe-content inset. Stage cards use the 900x1500 Game Crafter tarot template, finish at 2.75 x 4.75 in, and are designed to be read landscape. Stage body text uses a 58 px minimum, approximately 14 pt at 300 dpi.
