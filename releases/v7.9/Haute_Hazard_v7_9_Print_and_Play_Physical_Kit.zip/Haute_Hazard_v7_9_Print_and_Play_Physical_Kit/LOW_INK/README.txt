Haute & Hazard v7.9 — Low-Ink Print & Play

This optional home-print variant keeps the current layout but converts large dark fills to mostly white and renders light-on-dark text as strong dark text.
It is intended to reduce ink use, reduce dark-edge chipping, and improve inkjet text legibility.
Stage cards are 2.75 x 4.75 in tarot size, matching the Game Crafter Stage cards, and are laid out right-side-up landscape for play. The home-print Stage sheets use a safer 4-up Letter landscape layout.
Files alternate front/back pages for long-edge duplex printing. Print at Actual Size / 100% and test one sheet before printing the full set.
