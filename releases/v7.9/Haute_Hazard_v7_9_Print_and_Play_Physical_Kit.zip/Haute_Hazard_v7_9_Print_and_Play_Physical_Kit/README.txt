Haute & Hazard v7.9 Print & Play

Print at Actual Size / 100%. Cut on the visible card borders. Opaque sleeves are recommended.
Front/back PDFs use repeated shared backs and are intended for manual duplex alignment or sleeving.
Use 00_START_HERE.pdf before play.
