Haute & Hazard v7.9 Print & Play

Print at Actual Size / 100%. Cut on the visible card borders. Opaque sleeves are recommended.
Core game cards finish at 2.5 x 3.5 inches. Stage cards finish at 2.75 x 4.75 inches and are printed/read landscape, matching the Game Crafter tarot Stage size.
The numbered front-only/back-only PDFs support single-sided printing and sleeving.
The 10–13 DUPLEX PDFs combine each front sheet with its mirrored back sheet for long-edge duplex printing. Test one sheet first because printer registration varies.
LOW_INK contains duplex-ready versions with mostly white backgrounds and strong dark text for cheaper, more legible inkjet printing.
Use 00_START_HERE.pdf before play.
