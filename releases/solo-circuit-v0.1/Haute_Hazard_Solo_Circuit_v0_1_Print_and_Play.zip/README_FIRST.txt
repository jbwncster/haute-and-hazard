HAUTE & HAZARD - SOLO CIRCUIT v0.1 PRINT & PLAY

PRINT:
- 01 Automa cards: Letter, Actual Size / 100%, single-sided.
- 02 Personality cards: Letter, Actual Size / 100%, single-sided.
- 03 Quick Reference: Letter; cut page in half for two copies.
- 04 Playtest Log: Letter.

EASIEST CARD METHOD:
Cut the cards and sleeve them with spare poker/trading cards behind them. Opaque sleeves are recommended.

CONTENTS:
18 Automa cards
12 House Queen Personality cards
2-up quick reference
Solo playtest log

This is an EXPERIMENTAL PLAYTEST MODULE and is not part of canonical v7.8.
Dragdagulan† is working prototype terminology subject to legal/IP and publisher review.
